#ifndef MSLEEP_H
#define MSLEEP_H

int msleep(unsigned int tms);

#endif
