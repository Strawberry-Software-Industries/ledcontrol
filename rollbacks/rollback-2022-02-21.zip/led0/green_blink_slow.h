#ifndef GREEN_BLINK_SLOW_H
#define GREEN_BLINK_SLOW_H

int green_blink_slow();

#endif