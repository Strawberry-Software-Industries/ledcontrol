#ifndef GREEN_BLINK_FAST_H
#define GREEN_BLINK_FAST_H

int green_blink_fast();

#endif