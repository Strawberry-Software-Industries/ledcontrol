#ifndef ACTIVATE_GREEN_H
#define ACTIVATE_GREEN_H

int activate_green();

#endif