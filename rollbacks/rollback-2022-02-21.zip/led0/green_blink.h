#ifndef GREEN_BLINK_H
#define GREEN_BLINK_H

int green_blink();

#endif