#ifndef LEDMAP_H
#define LEDMAP_H

int mapper();
void check_model_config();

#endif
