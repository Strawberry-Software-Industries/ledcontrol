#define VERSION             "1.2 Pre-Release 7"
#define BUILD_DATE          "2022-02-21"