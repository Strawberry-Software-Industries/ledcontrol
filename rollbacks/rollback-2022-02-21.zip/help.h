#ifndef HELP_H
#define HELP_H

int help();

#endif
