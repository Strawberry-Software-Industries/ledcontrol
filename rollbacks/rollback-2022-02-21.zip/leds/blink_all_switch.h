#ifndef BLINK_ALL_SWITCH_H
#define BLINK_ALL_SWITCH_H

int blink_all_switch();

#endif