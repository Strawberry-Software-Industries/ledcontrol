#ifndef BLINK_ALL_SYNC_H
#define BLINK_ALL_SYNC_H

int blink_all_sync();

#endif