#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "ledmap.h"
#include "include/colors.h"
#include "ledmap/confpi3.h"
#include "ledmap/confpi4.h"

int mapper() {
    printf(BOLD LIGHT_CYAN"l" GREEN "e" YELLOW "d" BLUE "c" MAGENTA "o" CYAN "n" LIGHT_BLUE "t" RED "r" LIGHT_GREEN "o" LIGHT_MAGENTA "l" RESET BOLD " - config\n");
    printf("************************************************\n" RESET);
    printf(BOLD LIGHT_BLUE "Commands:\n" RESET);
    printf(BOLD CYAN "     --config-rpi4 [conf-pi4]: " RESET "Activates the recommended settings for Rapsberry Pi 4 devices\n");
    printf(BOLD CYAN "     --config-rpi3 [conf-pi3]: " RESET "Activates the recommended settings for Rapsberry Pi 3 devices\n");

    check_model_config();
  return 0;
}

void check_model_config() {
  char *str_pi4 = "RPi4";
  char *str_pi3 = "RPi3";
  char * model_map;

  char * buffer = 0;
  long length;
  FILE *fptr;
  fptr = fopen("/home/pi/.config/ledcontrol/ledmap.conf", "r");
  

  if (fptr){
        fseek (fptr, 0, SEEK_END);
        length = ftell (fptr);
        fseek (fptr, 0, SEEK_SET);
        buffer = malloc (length);
        if (buffer) {
            fread (buffer, 1, length, fptr);
        }
        fclose (fptr);
    }

  if (strcmp(buffer, str_pi4) == 0) {
    model_map = "Pi4";
  }
  else if (strcmp(buffer, str_pi3) == 0) {
    model_map = "Pi3";
  }
  printf("\n");
  printf(buffer);
  printf("\n");
  printf(model_map);
  printf("\n");
}


