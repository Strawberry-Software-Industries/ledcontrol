#ifndef RED_BLINK_SLOW_H
#define RED_BLINK_SLOW_H

int red_blink_slow();

#endif