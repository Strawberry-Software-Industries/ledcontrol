#ifndef ACTIVATE_RED_H
#define ACTIVATE_RED_H

int activate_red();

#endif