#ifndef RED_BLINK_FAST_H
#define RED_BLINK_FAST_H

int red_blink_fast();

#endif