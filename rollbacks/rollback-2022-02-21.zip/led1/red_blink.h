#ifndef RED_BLINK_H
#define RED_BLINK_H

int red_blink();

#endif