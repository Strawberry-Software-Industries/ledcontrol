#ifndef CONFPI3_H
#define CONFPI3_H

int confpi3();

#endif