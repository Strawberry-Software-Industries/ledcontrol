#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "config_dir.h"

void config_dir() {
  struct stat st = {0};

  if (stat("/home/pi/.config/ledcontrol/", &st) == -1) {
      mkdir("/home/pi/.config/ledcontrol/", 0700);
  }
}