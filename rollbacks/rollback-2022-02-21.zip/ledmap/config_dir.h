#ifndef CONFIG_DIR_H
#define CONFIG_DIR_H

void config_dir();

#endif
