#ifndef CONFPI4_H
#define CONFPI4_H

int confpi4();

#endif