#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "../ledmap.h"
#include "../include/colors.h"
#include "confpi3.h"
#include "config_dir.h"

int confpi3() {
  config_dir();

    char* model;
    char * buffer = 0;
    long length;
    model = "RPi3";
    FILE *fptr;

    fptr = fopen("/home/pi/.config/ledcontrol/ledmap.conf", "w");

    if (fptr == NULL) {
        printf(RED "Error creating Config File!\n");
        exit(1);
    }

    fprintf(fptr, "%s", model);
    fclose(fptr);
    printf("Changed #MODEL_CONFIG to RPi3\n");

    return 0;
}

