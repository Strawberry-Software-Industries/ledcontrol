#ifndef VERSION_H
#define VERSION_H

int version();

#endif
